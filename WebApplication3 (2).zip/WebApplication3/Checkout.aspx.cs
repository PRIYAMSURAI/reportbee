﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
namespace WebApplication3
{
    public partial class Checkout : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(@"Data Source=192.168.0.245\sqlexpress2008;Initial Catalog=LibraryManagement;Integrated Security=False;uid=trainee;pwd=trainee");
                {
                    conn.Open();
                    string username = (Session["Username"]).ToString();
                    SqlCommand xp = new SqlCommand("Select Name from PriyamFBAdmin Where Name= '" + username + "' ", conn);
                    SqlDataReader dr = xp.ExecuteReader();
                    if (dr.HasRows)
                    {
                        Button2.Style["display"] = "block";

                    }
                }
            }
            catch (Exception ex)
            {
             
                 string message = "Session Expired";
                            System.Text.StringBuilder sb = new System.Text.StringBuilder();
                            sb.Append("<script type = 'text/javascript'>");
                            sb.Append("window.onload=function(){");
                            sb.Append("alert('");
                            sb.Append(message);
                            sb.Append("')};");
                            sb.Append("</script>");
                            ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
                        
            
                  }


        }
        protected void cart(object sender, EventArgs e)
        {
           
            Response.Redirect("cart.aspx");
        }
        protected void logout(object sender, EventArgs e)
        {
            Session.Clear();
            Session.Abandon();
            Response.Redirect("Login.aspx");
        }
        protected void controlpanel(object sender, EventArgs e)
        {
            Response.Redirect("controlpanel.aspx");
        }


        protected void checkoutorder(object sender, EventArgs e)
        {
            
            
            SqlConnection conn = new SqlConnection(@"Data Source=192.168.0.245\sqlexpress2008;Initial Catalog=LibraryManagement;Integrated Security=False;uid=trainee;pwd=trainee");
            int count = 1;
            int totalcost = 0;
            conn.Open();
            SqlCommand xs = new SqlCommand("SELECT count(*) from PriyamAddCustomer", conn);
            count = 1 + (Int32.Parse((xs.ExecuteScalar().ToString()).Trim()));
            conn.Close();
            {
                conn.Open();
                SqlCommand xe = new SqlCommand("SELECT SUM(LineAmount) from PriyamAddOrder Where OrderId='"+count+"' ", conn);
               

                totalcost = 0 + (Int32.Parse((xe.ExecuteScalar().ToString()).Trim()));
                conn.Close();
                

                SqlCommand xp = new SqlCommand("insert into PriyamAddCustomer(Date,Name,Address,OrderAmount,Contact) Values(@date,@name,@address,@orderamount,@contact)", conn);
                string address = "" + (((TextBox3.Text).ToString()).Trim()) + (((TextBox4.Text).ToString()).Trim()) + (((DropDownList2.Text).ToString()).Trim()) + (((TextBox5.Text).ToString()).Trim());
                String date=""+ DateTime.Now.ToString("dd/MM/yyyy");

                xp.Parameters.AddWithValue("@name", TextBox1.Text);
                xp.Parameters.AddWithValue("@contact", TextBox2.Text);
                xp.Parameters.AddWithValue("@address", address);
                xp.Parameters.AddWithValue("@date", date);
                xp.Parameters.AddWithValue("@orderamount", totalcost);
                conn.Open();
                xp.ExecuteNonQuery();
                conn.Close();
            }

            string message = "Your Order Will Be Delivered Within 7 working Days";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append("<script type = 'text/javascript'>");
            sb.Append("window.onload=function(){");
            sb.Append("alert('");
            sb.Append(message);
            sb.Append("')};");
            sb.Append("</script>");
            ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());



        }



    }
}