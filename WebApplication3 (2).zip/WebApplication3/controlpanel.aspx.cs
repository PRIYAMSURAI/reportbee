﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace WebApplication3
{
    public partial class controlpanel : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void additem(object sender, EventArgs e)
        {

            Response.Redirect("controlpanelitem.aspx");
        }
        protected void cart(object sender, EventArgs e)
        {
            Response.Redirect("cart.aspx");
        }
        protected void logout(object sender, EventArgs e)
        {
            Session.Clear();
            Session.Abandon();
            Response.Redirect("Login.aspx");
        }

        protected void Add(object sender, EventArgs e)
        {
            string dbirth = "" + ((DropDownList4.Text).ToString()) + "-" + ((DropDownList5.Text).ToString()) + "-" + ((DropDownList6.Text).ToString());
            SqlConnection conn = new SqlConnection(@"Data Source=192.168.0.245\sqlexpress2008;Initial Catalog=LibraryManagement;Integrated Security=False;uid=trainee;pwd=trainee");
            conn.Open();
            SqlCommand xx = new SqlCommand("Select Email,Contact from PriyamFBAdmin Where Email='" + TextBox3.Text + "'", conn);
            SqlDataReader dr = xx.ExecuteReader();
            if (dr.HasRows)
            {
                conn.Close();
                string message = "Admin Data Already Exists";
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append("<script type = 'text/javascript'>");
                sb.Append("window.onload=function(){");
                sb.Append("alert('");
                sb.Append(message);
                sb.Append("')};");
                sb.Append("</script>");
                ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
           
            }
            else
            {
                conn.Open();
                SqlCommand xp = new SqlCommand("insert into PriyamFBAdmin(Name,Email,Contact,DOB) Values(@name,@email,@contact,@dob)", conn);
                xp.Parameters.AddWithValue("@name", TextBox1.Text);
                xp.Parameters.AddWithValue("@email", TextBox3.Text);
                xp.Parameters.AddWithValue("@contact", TextBox2.Text);
                xp.Parameters.AddWithValue("@dob", dbirth);
                conn.Open();
                xp.ExecuteNonQuery();
                conn.Close();
                string message = "Admin Data Updated Successfully";
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append("<script type = 'text/javascript'>");
                sb.Append("window.onload=function(){");
                sb.Append("alert('");
                sb.Append(message);
                sb.Append("')};");
                sb.Append("</script>");
                ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
            }
        }
    }
}