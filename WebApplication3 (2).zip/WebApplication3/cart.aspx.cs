﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace WebApplication3
{
    public partial class cart : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(@"Data Source=192.168.0.245\sqlexpress2008;Initial Catalog=LibraryManagement;Integrated Security=False;uid=trainee;pwd=trainee");
                {
                    conn.Open();
                    string username = (Session["Username"]).ToString();
                    SqlCommand xp = new SqlCommand("Select Name from PriyamFBAdmin Where Name= '" + username + "' ", conn);
                    SqlDataReader dr = xp.ExecuteReader();
                    if (dr.HasRows)
                    {
                        Button2.Style["display"] = "block";

                    }
                }

            }
            catch (Exception ex)
            {
                 string message = "Session Expired";
                            System.Text.StringBuilder sb = new System.Text.StringBuilder();
                            sb.Append("<script type = 'text/javascript'>");
                            sb.Append("window.onload=function(){");
                            sb.Append("alert('");
                            sb.Append(message);
                            sb.Append("')};");
                            sb.Append("</script>");
                            ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
                        
            
            }

            if (IsPostBack == false)
            {

                string mySelectQuery = "SELECT ProductName,Description,Amount,Images,Type FROM PriyamItem";
                SqlConnection myConnection = new SqlConnection(@"Data Source=192.168.0.245\sqlexpress2008;Initial Catalog=LibraryManagement;Integrated Security=False;uid=trainee;pwd=trainee");
                SqlCommand myCommand = new SqlCommand(mySelectQuery, myConnection);
                myConnection.Open();
                SqlDataReader myReader;
                myReader = myCommand.ExecuteReader();

                myRepeater.DataSource = myReader;
                myRepeater.DataBind();

                myReader.Close();
                myConnection.Close();


            }

        }
        protected void logout(object sender, EventArgs e)
        {
            Session.Clear();
            Session.Abandon();
            Response.Redirect("Login.aspx");
        }
        protected void controlpanel(object sender, EventArgs e)
        {
            Response.Redirect("controlpanel.aspx");
        }


        protected void checkout(object sender, EventArgs e)
        {
            int count = 1;
           
            SqlConnection conn = new SqlConnection(@"Data Source=192.168.0.245\sqlexpress2008;Initial Catalog=LibraryManagement;Integrated Security=False;uid=trainee;pwd=trainee");
            conn.Open();
            SqlCommand xs = new SqlCommand("SELECT count(*) from PriyamAddCustomer", conn);
            count = 1 + (Int32.Parse((xs.ExecuteScalar().ToString()).Trim()));
            conn.Close();
            
            foreach (RepeaterItem i in myRepeater.Items)
            {
                conn.Open();
                int quantity = 0;
                int amount = 0;
                int total = 0;
                string productname = "";
                TextBox txtExample = (TextBox)i.FindControl("TextBox1");
                Label labelexample = (Label)i.FindControl("Label1");
                if (txtExample != null)
                {

                    SqlCommand xp = new SqlCommand("SELECT Amount from PriyamItem Where ProductName='" + (((labelexample.Text).ToString()).Trim()) + "'", conn);
                    quantity = 0 + (Int32.Parse((txtExample.Text).ToString()));
                    amount = 0 + (Int32.Parse((xp.ExecuteScalar().ToString()).Trim()));
                    total =  (quantity *amount );
                    productname = "" + (((labelexample.Text).ToString()).Trim());
                    conn.Close();

                    SqlCommand xe = new SqlCommand("insert into PriyamAddOrder(OrderId,Product,Quantity,Price,LineAmount) Values(@orderid,@productname,@quantity,@price,@lineamount)", conn);
                 
                    xe.Parameters.AddWithValue("@orderid", count);
                    xe.Parameters.AddWithValue("@productname", productname);
                    xe.Parameters.AddWithValue("@quantity", quantity);
                    xe.Parameters.AddWithValue("@price", amount);
                    xe.Parameters.AddWithValue("@lineamount",total);
                    conn.Open();
                    xe.ExecuteNonQuery();
                    conn.Close();

                }
            }
            
            
            
            Response.Redirect("checkout.aspx");
        }




        protected void Electronics(object sender, EventArgs e)
        {
            ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "ElectronicsButton()", true);                      
            SqlConnection conn = new SqlConnection(@"Data Source=192.168.0.245\sqlexpress2008;Initial Catalog=LibraryManagement;Integrated Security=False;uid=trainee;pwd=trainee");
            conn.Open();

            string mySelectQuery = "SELECT ProductName,Description,Amount,Images,Type FROM PriyamItem where Type = 'Electronics'";
            SqlConnection myConnection = new SqlConnection(@"Data Source=192.168.0.245\sqlexpress2008;Initial Catalog=LibraryManagement;Integrated Security=False;uid=trainee;pwd=trainee");
            SqlCommand myCommand = new SqlCommand(mySelectQuery, myConnection);
            myConnection.Open();
            SqlDataReader myReader;
            myReader = myCommand.ExecuteReader();

            myRepeater.DataSource = myReader;
            myRepeater.DataBind();

            myReader.Close();
            myConnection.Close();
           
            foreach (RepeaterItem i in myRepeater.Items)
            {                
                Label labelexample = (Label)i.FindControl("Label1");
                SqlCommand xp = new SqlCommand("SELECT Type from PriyamItem Where ProductName='" + (((labelexample.Text).ToString()).Trim()) + "'", conn);
              string check=((xp.ExecuteScalar().ToString()).Trim());
                if( check !="Electronics")
               {
                   ((TextBox)i.FindControl("TextBox1")).Style["display"] = "none";
                   ((Label)i.FindControl("Label1")).Style["display"] = "none";
                   ((Label)i.FindControl("Label2")).Style["display"] = "none";
                   ((Label)i.FindControl("Label3")).Style["display"] = "none";
                   ((Image)i.FindControl("Image1")).Style["display"] = "none";
               }
               
            }
        
        }
        protected void Cloths(object sender, EventArgs e)
        {
            ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "ClothsButton()", true);
            
            SqlConnection conn = new SqlConnection(@"Data Source=192.168.0.245\sqlexpress2008;Initial Catalog=LibraryManagement;Integrated Security=False;uid=trainee;pwd=trainee");
            conn.Open();

            string mySelectQuery = "SELECT ProductName,Description,Amount,Images,Type FROM PriyamItem where Type = 'Cloths'";
            SqlConnection myConnection = new SqlConnection(@"Data Source=192.168.0.245\sqlexpress2008;Initial Catalog=LibraryManagement;Integrated Security=False;uid=trainee;pwd=trainee");
            SqlCommand myCommand = new SqlCommand(mySelectQuery, myConnection);
            myConnection.Open();
            SqlDataReader myReader;
            myReader = myCommand.ExecuteReader();

            myRepeater.DataSource = myReader;
            myRepeater.DataBind();

            myReader.Close();
            myConnection.Close();


            foreach (RepeaterItem i in myRepeater.Items)
            {
                Label labelexample = (Label)i.FindControl("Label1");
                SqlCommand xp = new SqlCommand("SELECT Type from PriyamItem Where ProductName='" + (((labelexample.Text).ToString()).Trim()) + "'", conn);
                if (((xp.ExecuteScalar().ToString()).Trim()) != "Cloths")
                {
                    ((TextBox)i.FindControl("TextBox1")).Style["display"] = "none";
                    ((Label)i.FindControl("Label1")).Style["display"] = "none";
                    ((Label)i.FindControl("Label2")).Style["display"] = "none";
                    ((Label)i.FindControl("Label3")).Style["display"] = "none";
                    ((Label)i.FindControl("Label4")).Style["display"] = "none";
                    ((Label)i.FindControl("Label5")).Style["display"] = "none";
                    ((Image)i.FindControl("Image1")).Style["display"] = "none";
                }
            }
        
        
        
        }
        protected void Shoes(object sender, EventArgs e)
        {
            ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "ShoesButton()", true);
            
            SqlConnection conn = new SqlConnection(@"Data Source=192.168.0.245\sqlexpress2008;Initial Catalog=LibraryManagement;Integrated Security=False;uid=trainee;pwd=trainee");
            conn.Open();

            string mySelectQuery = "SELECT ProductName,Description,Amount,Images,Type FROM PriyamItem where Type = 'Shoes'";
            SqlConnection myConnection = new SqlConnection(@"Data Source=192.168.0.245\sqlexpress2008;Initial Catalog=LibraryManagement;Integrated Security=False;uid=trainee;pwd=trainee");
            SqlCommand myCommand = new SqlCommand(mySelectQuery, myConnection);
            myConnection.Open();
            SqlDataReader myReader;
            myReader = myCommand.ExecuteReader();

            myRepeater.DataSource = myReader;
            myRepeater.DataBind();

            myReader.Close();
            myConnection.Close();


            foreach (RepeaterItem i in myRepeater.Items)
            {
                Label labelexample = (Label)i.FindControl("Label1");
                SqlCommand xp = new SqlCommand("SELECT Type from PriyamItem Where ProductName='" + (((labelexample.Text).ToString()).Trim()) + "'", conn);
                if (((xp.ExecuteScalar().ToString()).Trim()) != "Shoes")
                {
                    ((TextBox)i.FindControl("TextBox1")).Style["display"] = "none";
                    ((Label)i.FindControl("Label1")).Style["display"] = "none";
                    ((Label)i.FindControl("Label2")).Style["display"] = "none";
                    ((Label)i.FindControl("Label3")).Style["display"] = "none";
                    ((Label)i.FindControl("Label4")).Style["display"] = "none";
                    ((Label)i.FindControl("Label5")).Style["display"] = "none";
                    ((Image)i.FindControl("Image1")).Style["display"] = "none";
                }
            }
        
        
        
        
        }
        protected void Books(object sender, EventArgs e)
        {
            ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "BooksButton()", true);
            
            SqlConnection conn = new SqlConnection(@"Data Source=192.168.0.245\sqlexpress2008;Initial Catalog=LibraryManagement;Integrated Security=False;uid=trainee;pwd=trainee");
            conn.Open();

            string mySelectQuery = "SELECT ProductName,Description,Amount,Images,Type FROM PriyamItem where Type = 'Books'";
            SqlConnection myConnection = new SqlConnection(@"Data Source=192.168.0.245\sqlexpress2008;Initial Catalog=LibraryManagement;Integrated Security=False;uid=trainee;pwd=trainee");
            SqlCommand myCommand = new SqlCommand(mySelectQuery, myConnection);
            myConnection.Open();
            SqlDataReader myReader;
            myReader = myCommand.ExecuteReader();

            myRepeater.DataSource = myReader;
            myRepeater.DataBind();

            myReader.Close();
            myConnection.Close();


            foreach (RepeaterItem i in myRepeater.Items)
            {
                Label labelexample = (Label)i.FindControl("Label1");
                SqlCommand xp = new SqlCommand("SELECT Type from PriyamItem Where ProductName='" + (((labelexample.Text).ToString()).Trim()) + "'", conn);
                if (((xp.ExecuteScalar().ToString()).Trim()) != "Books")
                {
                    ((TextBox)i.FindControl("TextBox1")).Style["display"] = "none";
                    ((Label)i.FindControl("Label1")).Style["display"] = "none";
                    ((Label)i.FindControl("Label2")).Style["display"] = "none";
                    ((Label)i.FindControl("Label3")).Style["display"] = "none";
                    ((Label)i.FindControl("Label4")).Style["display"] = "none";
                    ((Label)i.FindControl("Label5")).Style["display"] = "none";
                    ((Image)i.FindControl("Image1")).Style["display"] = "none";
                }
            }
        
        
        }

    }
}