﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace WebApplication3
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void login(object sender, EventArgs e)
        {
            {
                SqlConnection conn = new SqlConnection(@"Data Source=192.168.0.245\sqlexpress2008;Initial Catalog=LibraryManagement;Integrated Security=False;uid=trainee;pwd=trainee");
                {
                    conn.Open();
                    SqlCommand xx = new SqlCommand("Select Email from PriyamFBREG Where Email='" + TextBox1.Text + "'", conn);
                    SqlDataReader dr = xx.ExecuteReader();
                    if (dr.HasRows)
                    {
                        conn.Close();
                        conn.Open();

                        SqlCommand xp = new SqlCommand("Select Password from PriyamFBREG Where email='" + TextBox1.Text + "'", conn);
                        xp.ExecuteNonQuery();
                   
                        if ((TextBox2.Text) == ((xp.ExecuteScalar().ToString()).Trim()))
                        {
                            SqlCommand xs = new SqlCommand("Select Name from PriyamFBREG Where email='" + TextBox1.Text + "'", conn);
                            string username = (xs.ExecuteScalar().ToString());
                            Session["Username"] = username ;
                      
                            Response.Redirect("cart.aspx");
                            //-------------------------Nextpage ends--------------------------------//
                        }
                        else
                        {   //------------------Alert-------------------------//
                            string message = "You have entered Wrong Password ";
                            System.Text.StringBuilder sb = new System.Text.StringBuilder();
                            sb.Append("<script type = 'text/javascript'>");
                            sb.Append("window.onload=function(){");
                            sb.Append("alert('");
                            sb.Append(message);
                            sb.Append("')};");
                            sb.Append("</script>");
                            ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
                            //------------------Alert-----------------------//           
                        }
                    }
                    else
                    {
                        string message = "You have entered Wrong Email ";
                        System.Text.StringBuilder sb = new System.Text.StringBuilder();
                        sb.Append("<script type = 'text/javascript'>");
                        sb.Append("window.onload=function(){");
                        sb.Append("alert('");
                        sb.Append(message);
                        sb.Append("')};");
                        sb.Append("</script>");
                        ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
                    
                    }
                    
                    conn.Close();
                }

            }


        }
    }
}