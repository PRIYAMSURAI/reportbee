﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace WebApplication3
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void register(object sender, EventArgs e)
        {
            string value = "";
            bool isChecked = RadioButton1.Checked;
            if(isChecked )
            {     value=RadioButton1.Text;}
            else
            { value=RadioButton2.Text;}

            string dbirth=""+((DropDownList4.Text).ToString())+"-"+((DropDownList5.Text).ToString())+"-"+((DropDownList6.Text).ToString());
            SqlConnection conn = new SqlConnection(@"Data Source=192.168.0.245\sqlexpress2008;Initial Catalog=LibraryManagement;Integrated Security=False;uid=trainee;pwd=trainee");
        
            SqlCommand xp = new SqlCommand("insert into PriyamFBREG(Name,Email,Contact,Gender,Country,State,City,Password,DOB) Values(@name,@email,@contact,@gender,@country,@state,@city,@password,@dob)", conn);
            xp.Parameters.AddWithValue("@name", TextBox3.Text);          
            xp.Parameters.AddWithValue("@email", TextBox4.Text);
            xp.Parameters.AddWithValue("@contact", TextBox5.Text);
            xp.Parameters.AddWithValue("@gender", value);
            xp.Parameters.AddWithValue("@country", DropDownList1.Text);
            xp.Parameters.AddWithValue("@state", DropDownList2.Text);
            xp.Parameters.AddWithValue("@city", DropDownList3.Text);
            xp.Parameters.AddWithValue("@password", TextBox6.Text);
            xp.Parameters.AddWithValue("@dob", dbirth);
            conn.Open();
            xp.ExecuteNonQuery();
            conn.Close();
            Response.Redirect("Login.aspx"); 

        
        }



        protected void login(object sender, EventArgs e)
        {
            {
                SqlConnection conn = new SqlConnection(@"Data Source=192.168.0.245\sqlexpress2008;Initial Catalog=LibraryManagement;Integrated Security=False;uid=trainee;pwd=trainee");
                {
                    conn.Open();
                    SqlCommand xp = new SqlCommand("Select Password from PriyamFBREG Where email='" + TextBox1.Text + "'", conn);

                    if ((TextBox2.Text) == ((xp.ExecuteScalar().ToString()).Trim()))
                    {
                        SqlCommand xs = new SqlCommand("Select Name from PriyamFBREG Where email='" + TextBox1.Text + "'", conn);
                            
                        string username = (xs.ExecuteScalar().ToString());
                        Session["Username"] = username;
                       
                        Response.Redirect("cart.aspx");
                        //-------------------------Nextpage ends--------------------------------//
                    }
                    else
                    {   //------------------Alert-------------------------//
                        string message = "You have entered Wrong Password or Email-id";
                        System.Text.StringBuilder sb = new System.Text.StringBuilder();
                        sb.Append("<script type = 'text/javascript'>");
                        sb.Append("window.onload=function(){");
                        sb.Append("alert('");
                        sb.Append(message);
                        sb.Append("')};");
                        sb.Append("</script>");
                        ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
                        //------------------Alert-----------------------//           
                    }

                    xp.ExecuteNonQuery();
                    conn.Close();
                }

            }


        }
       

        
    }
}