﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace WebApplication3
{
    public partial class controlpanelitem : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void addadmin(object sender, EventArgs e)
        {
            
            Response.Redirect("controlpanel.aspx");
        }
        protected void logout(object sender, EventArgs e)
        {
            Session.Clear();
            Session.Abandon();
            Response.Redirect("Login.aspx");
        }
        protected void AddItem(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=192.168.0.245\sqlexpress2008;Initial Catalog=LibraryManagement;Integrated Security=False;uid=trainee;pwd=trainee");
            {
                

                SqlCommand xp = new SqlCommand("insert into PriyamItem(ProductName,Description,Amount,Images,Type) Values(@pname,@desc,@amount,@img,@type)", conn);
                xp.Parameters.AddWithValue("@pname", TextBox1.Text);
                xp.Parameters.AddWithValue("@desc", TextBox2.Text);
                xp.Parameters.AddWithValue("@amount", TextBox4.Text);
                xp.Parameters.AddWithValue("@img", FileUpload1.FileName);
                xp.Parameters.AddWithValue("@type", DropDownList1.Text);


                conn.Open();
                xp.ExecuteNonQuery();
                conn.Close();
                Response.Redirect("controlpanelitem.aspx");
            }
        
        
        }

        protected void cart(object sender, EventArgs e)
        {
            Response.Redirect("cart.aspx");
        }
    }
}