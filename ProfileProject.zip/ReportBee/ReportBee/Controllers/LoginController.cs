﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ReportBee.Models;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Configuration;

namespace ReportBee.Controllers
{
    public class LoginController : Controller
    {

        public ActionResult Registration()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Registration( reportbee user)
        {
            if (ModelState.IsValid)
            {
                using (priyam db = new priyam())
                {
                    db.reportbees.Add(user);
                    db.SaveChanges();
                }
                ModelState.Clear();
                return RedirectToAction("Home");

            }
            return View(user);
        }

          public ActionResult Home()
        {
                         
                    using (priyam dc = new priyam())
                    {
                        
                        return View(dc.reportbees.ToList());
                    }
                
        }
     
    }
}
