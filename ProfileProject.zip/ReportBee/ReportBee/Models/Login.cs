﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Globalization;
using System.Web.Security;

using System.Linq;
using System.Web;
using System.Web.Mvc;



namespace ReportBee.Models
{
    public class Login
    {
        public string Name { get; set; }
        public string ShortBio { get; set; }
        public string ProfPic { get; set; }
        public string Github { get; set; }
        public string Stackoverflow { get; set; }
        public string LinkedIn { get; set; }
        public string Education { get; set; }
        public string Skills { get; set; }
        public string Awards { get; set; }
        public string Interests { get; set; }
        public string Languages { get; set; }
       

    }
}
