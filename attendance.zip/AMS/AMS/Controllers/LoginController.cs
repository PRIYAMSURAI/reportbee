﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AMS.Models;
using Excel;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Configuration;

namespace AMS.Controllers
{
    public class LoginController : Controller
    {

        public ActionResult Registration()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Registration(PriyamFBREG user)
        {
         if (ModelState.IsValid)
            {
                using (DATABASE db = new DATABASE())
                {
                    db.PriyamFBREGs.Add(user);
                    db.SaveChanges();
                }
                ModelState.Clear();
                return RedirectToAction("Login");

            }
            return View(user);
        }

        
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(PriyamFBREG user)
        {
          
                using (DATABASE db = new DATABASE())
                {
                    var usr = db.PriyamFBREGs.Where(u => u.Name == user.Name && u.Password == user.Password).FirstOrDefault();
                    PriyamFBREG reg = new PriyamFBREG();
                    if ((usr != null) && (usr.Password == user.Password))
                    {   
                        Session["UserID"] = usr.Name;
                        string abc = usr.Name;

                        var usernm= db.PriyamFBAdmins.Where(u => u.Name == usr.Name ).FirstOrDefault();
                        PriyamFBAdmin admin = new PriyamFBAdmin();

                        if (usernm != null)
                        {
                            if ((usernm.Name).ToString().Trim() == (usr.Name).ToString().Trim())
                            {
                                Session["Admin"] = "Priyam";  //cookies for admin
                               
                            }
                        }

                        //cookies for username
                        HttpCookie usernameb = new HttpCookie("priyam");
                        HttpContext.Response.Cookies.Remove("priyam");
                        usernameb.Value = usr.Name.Split(' ').First();
                        //HttpContext.Response.SetCookie(usernameb);
                        usernameb.HttpOnly = true;
                        Response.Cookies.Add(usernameb);
                       

                        SqlConnection myConnection = new SqlConnection(@"Data Source=192.168.0.245\sqlexpress2008;Initial Catalog=LibraryManagement;Integrated Security=False;uid=trainee;pwd=trainee");
                        myConnection.Open();
                        //SqlCommand xp = new SqlCommand("SELECT ROUND(AVG(CAST(TotalWorkingHour AS FLOAT)),2) FROM PriyamWorking WHERE EmployeeName ='" + abc + "' and CAST(TotalWorkingHour AS FLOAT)>='7.00'", myConnection);
                        SqlCommand xp = new SqlCommand("SELECT SUM(CAST(TotalWorkingHour AS FLOAT)) FROM PriyamWorking WHERE EmployeeName ='" + abc + "' ", myConnection);
                        //SqlCommand xp1 = new SqlCommand("SELECT SUM(CAST(TotalWorkingHour AS FLOAT)) FROM PriyamWorking WHERE EmployeeName ='" + abc + "' AND (CAST(TotalWorkingHour AS FLOAT) > '2.00') and CAST(TotalWorkingHour AS FLOAT)<'7.00'", myConnection);
                        var sql1=xp.ExecuteScalar();
                        //var sql2=xp1.ExecuteScalar();
                        float temp3 = float.Parse(sql1.ToString());
                        SqlCommand xp0 = new SqlCommand("SELECT count(*) FROM (SELECT LogDate FROM PriyamWorking  WHERE (EmployeeName = '"+abc+"') INTERSECT SELECT Date FROM PriyamDate)I", myConnection);
                        var sql = xp0.ExecuteScalar();
                        //total compoff days
                        HttpCookie copof = new HttpCookie("priyam5");
                        HttpContext.Response.Cookies.Remove("priyam5");
                        copof.Value = sql.ToString();
                        copof.HttpOnly = true;
                        Response.Cookies.Add(copof);

                      
                        //join date of user
                         SqlCommand xp3 = new SqlCommand("SELECT CAST(doj AS DATETIME) from PriyamFBREG where Name='"+abc+"'", myConnection);
                        var sql4=xp3.ExecuteScalar();
                        int nwdays = 0;

                        SqlCommand xp6 = new SqlCommand("SELECT MAX(CAST(LogDate AS DATETIME)) from PriyamWorking", myConnection);
                        var sql6 = xp6.ExecuteScalar();

                        //no of days
                        DateTime a = new DateTime(2016, 04, 01);
                        //DateTime now = new DateTime(2017, 02, 28);

                        DateTime now2 = Convert.ToDateTime(sql6.ToString());
                        int monthcurrent = int.Parse(now2.ToString("yyyy.dd.MM").Split('.').Last());
                        int yearcurrent = int.Parse(now2.ToString("yyyy.dd.MM").Split('.').First());
                        string datecurrent = "";
                        if(monthcurrent!=12){ datecurrent=(yearcurrent)+"."+(monthcurrent+1).ToString("00")+".01"; }
                        else if(monthcurrent==12){ datecurrent=(yearcurrent+1)+".01."+"01";}
                               DateTime now = Convert.ToDateTime(datecurrent);
                       

                        DateTime userd = Convert.ToDateTime(sql4.ToString());
                        string a1 = a.ToString("yyyy.MM.dd");
                        string now1 = now.ToString("yyyy.MM.dd");
                        //string now1 = DateTime.Now.ToString("yyyy.MM.dd");

                        //no of holidays
                        //SqlCommand xp2 = new SqlCommand("SELECT count(*) from PriyamDate where Date BETWEEN '" + a1 + "' AND '" + now1 + "'", myConnection);
                        int holidaypermitted = 0;

                        //total days
                        TimeSpan ts = now - a;
                        int days = (Math.Abs(ts.Days))-1;//total working days till now
                        if (userd > a)
                        {
                            SqlCommand xp2 = new SqlCommand("SELECT count(*) from PriyamDate where convert(DATETIME,date) BETWEEN '" + userd + "' AND '" + now1 + "'", myConnection);
                           
                            var sql3 = xp2.ExecuteScalar();
                            int temp5 = int.Parse(sql3.ToString()); 

                            TimeSpan abcd =  userd-a;
                            int leaves1 = Math.Abs(abcd.Days);
                            nwdays = days - (leaves1+temp5);

                            int leave = int.Parse(userd.ToString("dd.yyyy.MM").Split('.').First());
                            if (leave < 16)
                            {
                                holidaypermitted = (((days - leaves1) / 30) + 1) * 2;
                            }
                            else { holidaypermitted = (((days - leaves1) / 30) * 2)+1; }

                            HttpCookie wrkd = new HttpCookie("priyam3");
                            HttpContext.Response.Cookies.Remove("priyam3");
                            wrkd.Value = nwdays.ToString();
                            wrkd.HttpOnly = true;
                            Response.Cookies.Add(wrkd);
                            
                        }
                        else
                        {//no of holidays
                            SqlCommand xp2 = new SqlCommand("SELECT count(*) from PriyamDate where convert(DATETIME,date) BETWEEN '" + a1 + "' AND '" + now1 + "'", myConnection);
                            int leave = int.Parse(now.ToString("yyyy.dd.MM").Split('.').Last())-1;
                            //holidaypermitted = ((days / 30) + 1) * 2;
                            //if (holidaypermitted > 24) { holidaypermitted = 0; }

                            if (leave == 4) { holidaypermitted = 2; }
                            else if (leave == 5) { holidaypermitted = 4; }
                            else if (leave == 6) { holidaypermitted = 6; }
                            else if (leave == 7) { holidaypermitted = 8; }
                            else if (leave == 8) { holidaypermitted = 10; }
                            else if (leave == 9) { holidaypermitted = 12; }
                            else if (leave == 10) { holidaypermitted = 14; }
                            else if (leave == 11) { holidaypermitted = 16; }
                            else if (leave == 12) { holidaypermitted = 18; }
                            else if (leave == 1) { holidaypermitted = 20; }
                            else if (leave == 2) { holidaypermitted = 22; }
                            else if (leave == 3) { holidaypermitted = 24; }
                            
                            var sql3 = xp2.ExecuteScalar();
                            int temp5 = int.Parse(sql3.ToString()); // value containing total holidays

                            nwdays = days-temp5;
                            HttpCookie wrkd = new HttpCookie("priyam3");
                            HttpContext.Response.Cookies.Remove("priyam3");
                            wrkd.Value = nwdays.ToString();
                            wrkd.HttpOnly = true;
                            Response.Cookies.Add(wrkd);
                       
                            
                        }

                        HttpCookie holidays = new HttpCookie("priyam6");
                        HttpContext.Response.Cookies.Remove("priyam6");
                        holidays.Value = holidaypermitted.ToString();
                        holidays.HttpOnly = true;
                        Response.Cookies.Add(holidays);


                        //float temp4 = float.Parse(sql2.ToString());
                        float totalattendance;
                        float temp;
                        using (Working d = new Working())
                        {
                            float temp1 = d.PriyamWorkings.SqlQuery(" SELECT * FROM PriyamWorking Where EmployeeName = {0} and CAST(TotalWorkingHour AS FLOAT)>='7.00'", abc).Count();
                            float temp2 = d.PriyamWorkings.SqlQuery(" SELECT * FROM PriyamWorking Where EmployeeName = {0} AND (CAST(TotalWorkingHour AS FLOAT) > '2.00') and CAST(TotalWorkingHour AS FLOAT)<'7.00'", abc).Count();
                            totalattendance = temp1 + (temp2 / 2);
                            //var atnd = totalattendance;
                            //temp = ((temp3 + ((2 * temp4) / temp2)) / 2);
                            temp = temp3 / totalattendance;
                            //var avgwrk = temp.ToString("0.00");
                        }
                        float leaves = float.Parse(nwdays.ToString()) - totalattendance;
                       
                        float holidayremaining = holidaypermitted - leaves;

                        //cookie for total holiday remaining
                        HttpCookie holiday = new HttpCookie("priyam4");
                        HttpContext.Response.Cookies.Remove("priyam4");
                        holiday.Value = holidayremaining.ToString();
                        holiday.HttpOnly = true;
                        Response.Cookies.Add(holiday);


                        //cookie for total holiday taken
                        HttpCookie holidaytk = new HttpCookie("priyam7");
                        HttpContext.Response.Cookies.Remove("priyam7");
                        holidaytk.Value = (leaves + int.Parse(sql.ToString())).ToString();
                        holidaytk.HttpOnly = true;
                        Response.Cookies.Add(holidaytk);

                        //cookie for total attendance
                        HttpCookie usernam = new HttpCookie("priyam1");
                        HttpContext.Response.Cookies.Remove("priyam1");
                        usernam.Value = totalattendance.ToString();

                        usernam.HttpOnly = true;
                        Response.Cookies.Add(usernam);
                        //cookie for avg working hours
                        HttpCookie userna = new HttpCookie("priyam2");
                        HttpContext.Response.Cookies.Remove("priyam2");
                        userna.Value = temp.ToString("0.00");
                        userna.HttpOnly = true;
                        Response.Cookies.Add(userna);

                        return RedirectToAction("home");
                    }
                    else
                    {
                        ModelState.AddModelError("", "Username Or Password is Wrong");
                    }
                }
            return View();
        }
       



        public ActionResult home()
        {
            

            if (Session["UserID"] != null)
            {
                               
                //ViewBag.Attendance = atnd;
                //ViewBag.AvgWork = avgwrk;                    
                    return View();
            }
            else { return RedirectToAction("Login"); }
              
        }


        public ActionResult LogOff()
        {
           
            HttpCookie usernameb = new HttpCookie("MyCookie");
            usernameb.Expires = DateTime.Now.AddDays(-1);
            Response.Cookies.Add(usernameb);
            Session["UserID"] = null;
            Session["Admin"] = null;
            return RedirectToAction("Login");
        }

    }
}
