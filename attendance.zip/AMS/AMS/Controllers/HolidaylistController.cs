﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AMS.Models;
using Excel;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Configuration;

namespace AMS.Controllers
{
    public class HolidaylistController : Controller
    {
        public ActionResult holidaylist()
        {
            if (Session["UserID"] != null)
            {
                using (Working db = new Working())
                {
                    return View(db.PriyamDates.SqlQuery("select * from PriyamDate").ToList());
                }
            }
            else { return RedirectToAction("Login"); }
        }

    }
}
