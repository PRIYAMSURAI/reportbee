﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AMS.Models;
using Excel;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Configuration;


namespace AMS.Controllers
{
    public class TotalattendanceController : Controller
    {

        public ActionResult totalattendancetable()
        {
            if (Session["UserID"] != null)
            {
                using (Working db = new Working())
                {
                    using (DATABASE dc = new DATABASE())
                    {
                        string abc = Session["UserID"].ToString();
                        multiple model = new multiple();
                        model.Daily = db.PriyamWorkings.SqlQuery("select * from PriyamWorking where EmployeeName={0}", abc).ToList();
                        model.User = db.PriyamDates.SqlQuery("select * from PriyamDate").ToList();
                        model.UserDetails = dc.PriyamFBREGs.SqlQuery("select * from PriyamFBREG").ToList();
                        return View(model);
                    }
                }
            }
            else { return RedirectToAction("Login"); }
        }
    }
}
