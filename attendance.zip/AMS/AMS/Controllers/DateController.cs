﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AMS.Models;
using Excel;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Configuration;


namespace AMS.Controllers
{
    public class DateController : Controller
    {
        public ActionResult date()
        {
            if (Session["UserID"] != null)
            {

                ViewBag.success = "";
                ViewBag.Error = "";
                return View();
            }
            else { return RedirectToAction("Login"); }
        }






        [ActionName("date")]
        [HttpPost]
        public ActionResult date1()
        {

            if (Request.Files["FileUpload1"].ContentLength > 0)
            {
                string extension = System.IO.Path.GetExtension(Request.Files["FileUpload1"].FileName).ToLower();

                string connString = "";

                string[] validFileTypes = { ".xls", ".xlsx", ".csv" };
                //string path1 = HttpContext.Current.Server.MapPath(string.Format("~/{0}", "Upload"));
                string path5 = string.Format(@"{0}\Dataa.csv", Server.MapPath("~/Content/Uploads"));
                string path1 = string.Format(@"{0}\{1}", Server.MapPath("~/Content/Uploads"), Request.Files["FileUpload1"].FileName.Split('\\').Last());

                if (!Directory.Exists(path1))
                {
                    Directory.CreateDirectory(Server.MapPath("~/Content/Uploads"));
                }

                if (validFileTypes.Contains(extension))
                {
                    if (System.IO.File.Exists(path1))
                    { System.IO.File.Delete(path1); }
                    Request.Files["FileUpload1"].SaveAs(path1);
                    System.IO.File.SetAttributes(path1, FileAttributes.Normal);
                    if (extension.Trim() == ".csv")
                    {

                        string line = null;
                        string line_to_delete = ",,,,";

                        using (StreamReader reader = new StreamReader(path1))
                        {
                            using (StreamWriter writer = new StreamWriter(path5))
                            {
                                while ((line = reader.ReadLine()) != null)
                                {
                                    if (String.Compare(line, line_to_delete) == 0)
                                        continue;

                                    writer.WriteLine(line);
                                }
                            }
                        }


                        DataTable dt = Utility.ConvertCSVtoDataTable(path5);
                        // ViewBag.Data = dt;

                        DataSet dsColMapping = new DataSet();
                        string path2 = string.Format(@"{0}\UploadType1.xml", Server.MapPath(@"~/xml"));
                        dsColMapping.ReadXml(path2);
                        using (SqlConnection dbConnection = new SqlConnection(@"Data Source=192.168.0.245\sqlexpress2008;Initial Catalog=LibraryManagement;Integrated Security=False;uid=trainee;pwd=trainee"))
                        {
                            dbConnection.Open();
                            using (SqlBulkCopy s = new SqlBulkCopy(dbConnection))
                            {
                                foreach (DataRow dr1 in dsColMapping.Tables[0].Rows)
                                {
                                    if (dt.Columns.Contains(Convert.ToString(dr1["SourceColumn"]).Trim()))
                                    {
                                        s.ColumnMappings.Add(Convert.ToString(dr1["SourceColumn"]).Trim(), Convert.ToString(dr1["DestinationColumn"]).Trim());
                                    }
                                    else
                                    {
                                        ViewBag.Error = "CSV is in incorrect format";
                                    }
                                }
                                s.DestinationTableName = "PriyamDate";
                                try
                                {
                                    s.WriteToServer(dt);
                                }
                                catch (Exception ex)
                                {
                                    ViewBag.Error = "not valid";
                                }
                            }
                        }
                        ViewBag.success = "File Successfully uploaded";
                        ViewBag.Error = "";

                    }

                }
                else
                {
                    ViewBag.success = "";
                    ViewBag.Error = "Please Upload Files in .xls, .xlsx or .csv format";

                }
            }
            return View();
        }

        public FileContentResult DownloadHolidaySample(string Stage, string ProductCode) //,string ProductName)
        {
            string SampleFile = Server.MapPath("~/Download");
            SampleFile = Path.Combine(SampleFile, "Holidays.csv");
            string fileName = "Holidays.csv";

            byte[] fileContent = new byte[] { };
            fileContent = System.IO.File.ReadAllBytes(SampleFile);
            return File(fileContent, "application/text", fileName);
        }




    }
}
