﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Globalization;
using System.Web.Mvc;
using System.Web.Security;

namespace AMS.Models
{
    public class Login
    {
        [Key]
        [Required(ErrorMessage = "* Name is required to continue")]
        public string Name { get; set; }
        [Required(ErrorMessage = "* Phone No is required to continue")]
        public int Contact { get; set; }
        [Required(ErrorMessage = "* Email is required to continue")]
        [RegularExpression(@"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*", ErrorMessage = "*Email Is not valid")]
        public string Email { get; set; }
        [Required(ErrorMessage = "* Password is required to continue")]
        [DataType(System.ComponentModel.DataAnnotations.DataType.Password)]
        //[StringLength(20, MinimumLength = 8, ErrorMessage = "Password should be in between 8-16 character")]
        public string Password { get; set; }


    }
}