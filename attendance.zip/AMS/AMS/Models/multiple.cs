﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Globalization;
using System.Web.Mvc;
using System.Web.Security;

namespace AMS.Models
{
    public class multiple
    {
        public List<PriyamWorking> Daily { get; set; }
        public List<PriyamDate> User { get; set; }
        public List<PriyamFBREG> UserDetails { get; set; }
    }
}