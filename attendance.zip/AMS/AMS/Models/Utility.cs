﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel;
using System.Data;
using Excel;
using System.Data.SqlClient;
using System.IO;
using System.Data.OleDb;  

namespace AMS.Models
{
    public static class Utility
    {
        public static DataTable ConvertCSVtoDataTable(string strFilePath)
        {
            DataTable dt = new DataTable();
            using (StreamReader sr = new StreamReader(strFilePath))
            {

                string[] headers = headers = sr.ReadLine().Split(','); 

                    foreach (string header in headers)
                    {
                        dt.Columns.Add(header);
                    }

                    while (!sr.EndOfStream)
                    {
                        string[] rows = sr.ReadLine().Split(',');
                        if (rows.Length > 1)
                        {
                            DataRow dr = dt.NewRow();
                            for (int i = 0; i < headers.Length; i++)
                            {
                                dr[i] = rows[i].Trim();
                            }
                            dt.Rows.Add(dr);
                        }
                    }              
            }


            return dt;
        }

        public static DataTable ConvertXSLXtoDataTable(string fileName, string filename2)
        {

            IExcelDataReader excelReader;
            Stream stream = File.Open(fileName, FileMode.Open);
            excelReader = GetExcelReader(fileName, stream, filename2);
            DataSet dsExcelDataSet = excelReader.AsDataSet(true);

            DataTable dt = new DataTable();
            if (dsExcelDataSet.Tables.Count > 0)
            {
                IEnumerator<DataRow> a = dsExcelDataSet.Tables[0].AsEnumerable().Skip(1).GetEnumerator();
                if (dsExcelDataSet.Tables[0].Rows.Count > 0)
                {
                    object[] dd = dsExcelDataSet.Tables[0].Rows[0].ItemArray;

                    foreach (var aa in dd)
                    {

                        dt.Columns.Add(aa.ToString(), typeof(string));
                    }

                    while (a.MoveNext())
                    {
                        dt.Rows.Add(a.Current.ItemArray);
                    }
                }
                else
                {
                    string Msg = "No data found in excel file";
                   
                    throw new Exception(Msg);
                }
            }
            else
            {
                string Msg = "No data found in excel file";
               
                throw new Exception(Msg);
            }
            return dt;

        }
        public static IExcelDataReader GetExcelReader(string filePath, Stream stream, string filename)
        {
            IExcelDataReader excelReader;
            //if (Path.GetExtension(filePath).ToLower() == ".xlsx")//Reading from a OpenXml Excel file (2007 format; *.xlsx)
            if (filename.ToLower() == ".xlsx")
            {
                excelReader = ExcelReaderFactory.CreateOpenXmlReader(stream);
            }
            else//Reading from a binary Excel file ('97-2003 format; *.xls)
            {
                excelReader = ExcelReaderFactory.CreateBinaryReader(stream);
            }
            return excelReader;
        }
    }  
}
